#!/bin/bash

#O script escolhe o arquivo do mês

mesAtual=$(date +%b) &&

if [ $mesAtual = "jan" ]; then
cat /tmp/02.txt

elif [ $mesAtual = "fev" ]; then
cat /tmp/01.txt

fi

exit
